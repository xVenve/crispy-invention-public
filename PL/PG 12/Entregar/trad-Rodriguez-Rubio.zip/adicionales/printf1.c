#include <stdio.h>

main () 
{
	printf ("El texto no se imprime %d", 123+1) ;
}

//@ (main)

