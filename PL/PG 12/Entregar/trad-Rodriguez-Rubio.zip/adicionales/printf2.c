// Prueba basica 2 de printf 
#include <stdio.h>

main () 
{
	printf ("El texto no se imprime %d %d", 123+1, 124+1) ;
}

//@ (main)

